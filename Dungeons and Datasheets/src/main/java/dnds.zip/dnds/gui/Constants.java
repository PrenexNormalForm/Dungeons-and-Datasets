package dnds.gui;

import javafx.stage.Stage;

public class Constants {
    static Stage stage;
    final static String START_WINDOW = "StartWindow";
    final static String SERVER_WINDOW = "ServerWindow";
    final static String SETTINGS_WINDOW = "SettingsWindow";
    static String PREVIOUS_WINDOW;
}
